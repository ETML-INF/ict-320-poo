// MenuDemo.cs - Demonstration of text input vs interactive menu
// For video recording purposes

// =====================================================
// GLOBAL VARIABLES
// =====================================================
string[] options = Array.Empty<string>();
int selectedIndex = 0;

// =====================================================
// MAIN PROGRAM
// =====================================================
Console.Title = "Menu Demo - Pre-OO Tutorial";
Console.CursorVisible = false;

bool exitDemo = false;

while (!exitDemo)
{
    Console.Clear();
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.WriteLine("╔════════════════════════════════════════════╗");
    Console.WriteLine("║         MENU DEMO - PRE-OO TUTORIAL        ║");
    Console.WriteLine("╠════════════════════════════════════════════╣");
    Console.WriteLine("║  1. Text Input Menu (ReadLine version)     ║");
    Console.WriteLine("║  2. Interactive Menu (Arrow keys version)  ║");
    Console.WriteLine("║  3. Exit Demo                              ║");
    Console.WriteLine("╚════════════════════════════════════════════╝");
    Console.ResetColor();
    Console.WriteLine();
    Console.Write("Choose demo (1-3): ");

    string? demoChoice = Console.ReadLine();

    switch (demoChoice)
    {
        case "1":
            Demo_TextInputMenu();
            break;
        case "2":
            Demo_InteractiveMenu();
            break;
        case "3":
            exitDemo = true;
            break;
    }
}

Console.Clear();
Console.WriteLine("Demo finished. Goodbye!");
Console.CursorVisible = true;

// =====================================================
// DEMO 1: TEXT INPUT MENU (ReadLine version)
// =====================================================
void Demo_TextInputMenu()
{
    bool running = true;

    while (running)
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("┌──────────────────────────────────────┐");
        Console.WriteLine("│   TEXT INPUT MENU (ReadLine version) │");
        Console.WriteLine("└──────────────────────────────────────┘");
        Console.ResetColor();
        Console.WriteLine();

        // Initialize options
        options = new string[] { "Play", "Options", "Highscores", "Quit" };

        // Display title
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("    ╔═══════════════════╗");
        Console.WriteLine("    ║    SUPER GAME     ║");
        Console.WriteLine("    ╚═══════════════════╝");
        Console.ResetColor();
        Console.WriteLine();

        // Display menu options using a loop
        for (int i = 0; i < options.Length; i++)
        {
            Console.WriteLine($"    {i + 1}. {options[i]}");
        }

        Console.WriteLine();
        Console.Write($"    Enter your choice (1-{options.Length}): ");

        // Get user input
        string? input = Console.ReadLine();

        // Validate and process choice
        if (int.TryParse(input, out int choice) && choice >= 1 && choice <= options.Length)
        {
            string selectedOption = options[choice - 1];

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"    >>> You selected: {selectedOption}");
            Console.ResetColor();

            // Handle the selection
            switch (selectedOption)
            {
                case "Play":
                    ShowGameScreen();
                    break;
                case "Options":
                    ShowOptionsScreen();
                    break;
                case "Highscores":
                    ShowHighscoresScreen();
                    break;
                case "Quit":
                    running = false;
                    Console.WriteLine();
                    Console.WriteLine("    Returning to demo menu...");
                    Thread.Sleep(1000);
                    break;
            }
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine();
            Console.WriteLine("    Invalid choice! Press any key...");
            Console.ResetColor();
            Console.ReadKey(true);
        }
    }
}

// =====================================================
// DEMO 2: INTERACTIVE MENU (Arrow keys version)
// =====================================================
void Demo_InteractiveMenu()
{
    bool running = true;

    while (running)
    {
        Menu_Init();
        int choice = Menu_RunInteractive();
        string selectedOption = options[choice - 1];

        switch (selectedOption)
        {
            case "Play":
                ShowGameScreen();
                break;
            case "Options":
                ShowOptionsScreen();
                break;
            case "Highscores":
                ShowHighscoresScreen();
                break;
            case "Quit":
                running = false;
                Console.Clear();
                Console.WriteLine("    Returning to demo menu...");
                Thread.Sleep(1000);
                break;
        }
    }
}

// =====================================================
// MENU FUNCTIONS (for interactive version)
// =====================================================

void Menu_Init()
{
    options = new string[] { "Play", "Options", "Highscores", "Quit" };
    selectedIndex = 0;
}

void Menu_AddOption(string option)
{
    string[] newOptions = new string[options.Length + 1];

    for (int i = 0; i < options.Length; i++)
    {
        newOptions[i] = options[i];
    }

    newOptions[options.Length] = option;
    options = newOptions;
}

void Menu_ShowInteractive()
{
    Console.Clear();

    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine("┌──────────────────────────────────────┐");
    Console.WriteLine("│  INTERACTIVE MENU (Arrow keys)       │");
    Console.WriteLine("└──────────────────────────────────────┘");
    Console.ResetColor();
    Console.WriteLine();

    // Title with ASCII art
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine("    ╔═══════════════════╗");
    Console.WriteLine("    ║    SUPER GAME     ║");
    Console.WriteLine("    ╚═══════════════════╝");
    Console.ResetColor();
    Console.WriteLine();

    Console.ForegroundColor = ConsoleColor.DarkGray;
    Console.WriteLine("    Use ↑↓ to navigate, Enter to select");
    Console.ResetColor();
    Console.WriteLine();

    for (int i = 0; i < options.Length; i++)
    {
        if (i == selectedIndex)
        {
            // Highlight selected option
            Console.Write("    ");
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write($"  ► {options[i],-12} ◄  ");
            Console.ResetColor();
            Console.WriteLine();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine($"      {options[i]}");
            Console.ResetColor();
        }
    }

    Console.WriteLine();
}

int Menu_RunInteractive()
{
    ConsoleKey key;

    do
    {
        Menu_ShowInteractive();

        // Read key without displaying it
        ConsoleKeyInfo keyInfo = Console.ReadKey(true);
        key = keyInfo.Key;

        // Handle navigation
        if (key == ConsoleKey.UpArrow)
        {
            selectedIndex--;
            if (selectedIndex < 0)
            {
                selectedIndex = options.Length - 1; // Wrap to bottom
            }
        }
        else if (key == ConsoleKey.DownArrow)
        {
            selectedIndex++;
            if (selectedIndex >= options.Length)
            {
                selectedIndex = 0; // Wrap to top
            }
        }

    } while (key != ConsoleKey.Enter);

    return selectedIndex + 1; // Return 1-based choice
}

// =====================================================
// GAME SCREENS (shared by both demos)
// =====================================================

void ShowGameScreen()
{
    Console.Clear();
    Console.ForegroundColor = ConsoleColor.Magenta;
    Console.WriteLine();
    Console.WriteLine("    ╔═══════════════════════════════════╗");
    Console.WriteLine("    ║           GAME STARTED!           ║");
    Console.WriteLine("    ╠═══════════════════════════════════╣");
    Console.WriteLine("    ║                                   ║");
    Console.WriteLine("    ║      Loading Level 1...           ║");
    Console.WriteLine("    ║                                   ║");
    Console.WriteLine("    ║      ████████████░░░░░░ 60%       ║");
    Console.WriteLine("    ║                                   ║");
    Console.WriteLine("    ║      Get ready to play!           ║");
    Console.WriteLine("    ║                                   ║");
    Console.WriteLine("    ╚═══════════════════════════════════╝");
    Console.ResetColor();
    Console.WriteLine();
    Console.WriteLine("    Press any key to return to menu...");
    Console.ReadKey(true);
}

void ShowOptionsScreen()
{
    Console.Clear();
    Console.ForegroundColor = ConsoleColor.Blue;
    Console.WriteLine();
    Console.WriteLine("    ╔═════════════════════════════════════╗");
    Console.WriteLine("    ║             OPTIONS                 ║");
    Console.WriteLine("    ╠═════════════════════════════════════╣");
    Console.WriteLine("    ║                                     ║");
    Console.WriteLine("    ║      Sound:      [ON]  OFF          ║");
    Console.WriteLine("    ║      Music:      [ON]  OFF          ║");
    Console.WriteLine("    ║      Difficulty: EASY [NORMAL] HARD ║");
    Console.WriteLine("    ║      Fullscreen: ON  [OFF]          ║");
    Console.WriteLine("    ║                                     ║");
    Console.WriteLine("    ╚═════════════════════════════════════╝");
    Console.ResetColor();
    Console.WriteLine();
    Console.WriteLine("    Press any key to return to menu...");
    Console.ReadKey(true);
}

void ShowHighscoresScreen()
{
    Console.Clear();
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine();
    Console.WriteLine("    ╔═══════════════════════════════════╗");
    Console.WriteLine("    ║           HIGHSCORES              ║");
    Console.WriteLine("    ╠═══════════════════════════════════╣");
    Console.WriteLine("    ║                                   ║");
    Console.WriteLine("    ║      1. AAA .............. 10000  ║");
    Console.WriteLine("    ║      2. BBB ..............  8500  ║");
    Console.WriteLine("    ║      3. CCC ..............  7200  ║");
    Console.WriteLine("    ║      4. DDD ..............  5100  ║");
    Console.WriteLine("    ║      5. EEE ..............  3400  ║");
    Console.WriteLine("    ║                                   ║");
    Console.WriteLine("    ╚═══════════════════════════════════╝");
    Console.ResetColor();
    Console.WriteLine();
    Console.WriteLine("    Press any key to return to menu...");
    Console.ReadKey(true);
}
