﻿// SnailRace.cs - Menu only (game logic to be added later)

// =====================================================
// GLOBAL VARIABLES
// =====================================================
string[] options = Array.Empty<string>();
int selectedIndex = 0;

// Configuration
int snailCount = 4;
int fatigueLevel = 2;  // 1=Low, 2=Medium, 3=High

// Betting
int playerMoney = 100;
int currentBet = 0;
int betOnSnail = -1;

// Statistics
int totalRaces = 0;
int wins = 0;
int losses = 0;

// =====================================================
// MAIN PROGRAM
// =====================================================
Console.Title = "Course d'Escargots";
Console.CursorVisible = false;

bool running = true;

while (running)
{
    Menu_Init();
    int choice = Menu_RunInteractive();

    switch (choice)
    {
        case 1:
            Action_StartRace();
            break;
        case 2:
            Action_Configure();
            break;
        case 3:
            Action_Bet();
            break;
        case 4:
            Action_Statistics();
            break;
        case 5:
            running = false;
            break;
    }
}

Console.Clear();
Console.WriteLine("Merci d'avoir joue! A bientot!");
Console.CursorVisible = true;

// =====================================================
// MENU FUNCTIONS
// =====================================================

void Menu_Init()
{
    options = new string[]
    {
        "Lancer la course",
        "Configurer",
        "Parier",
        "Statistiques",
        "Quitter"
    };
    selectedIndex = 0;
}

void Menu_Show()
{
    Console.Clear();

    // Title
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine();
    Console.WriteLine("    @@@'   COURSE D'ESCARGOTS   '@@@");
    Console.WriteLine("   @(_)@                        @(_)@");
    Console.WriteLine();
    Console.ResetColor();

    // Player info bar
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.WriteLine($"    Argent: {playerMoney}$  |  Pari: {currentBet}$ sur escargot #{betOnSnail + 1}");
    Console.ResetColor();
    Console.WriteLine();

    // Navigation hint
    Console.ForegroundColor = ConsoleColor.DarkGray;
    Console.WriteLine("    Utiliser ↑↓ pour naviguer, Entree pour selectionner");
    Console.ResetColor();
    Console.WriteLine();

    // Menu options
    for (int i = 0; i < options.Length; i++)
    {
        if (i == selectedIndex)
        {
            Console.Write("    ");
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write($" > {options[i],-20} ");
            Console.ResetColor();
            Console.WriteLine();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine($"      {options[i]}");
            Console.ResetColor();
        }
    }

    Console.WriteLine();
}

int Menu_RunInteractive()
{
    ConsoleKey key;

    do
    {
        Menu_Show();

        ConsoleKeyInfo keyInfo = Console.ReadKey(true);
        key = keyInfo.Key;

        if (key == ConsoleKey.UpArrow)
        {
            selectedIndex--;
            if (selectedIndex < 0)
            {
                selectedIndex = options.Length - 1;
            }
        }
        else if (key == ConsoleKey.DownArrow)
        {
            selectedIndex++;
            if (selectedIndex >= options.Length)
            {
                selectedIndex = 0;
            }
        }

    } while (key != ConsoleKey.Enter);

    return selectedIndex + 1;
}

// =====================================================
// ACTION FUNCTIONS (stubs for now)
// =====================================================

void Action_StartRace()
{
    Console.Clear();
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine();
    Console.WriteLine("    ════════════════════════════════");
    Console.WriteLine("           COURSE EN COURS...");
    Console.WriteLine("    ════════════════════════════════");
    Console.ResetColor();
    Console.WriteLine();
    Console.WriteLine($"    Nombre d'escargots: {snailCount}");
    Console.WriteLine($"    Niveau de fatigue: {GetFatigueName(fatigueLevel)}");
    Console.WriteLine();
    Console.WriteLine("    [La course sera implementee plus tard]");
    Console.WriteLine();

    // Simulate a winner
    totalRaces++;

    Console.WriteLine("    Appuyez sur une touche...");
    Console.ReadKey(true);
}

void Action_Configure()
{
    bool configuring = true;
    int configIndex = 0;

    while (configuring)
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine();
        Console.WriteLine("    ════════════════════════════════");
        Console.WriteLine("           CONFIGURATION");
        Console.WriteLine("    ════════════════════════════════");
        Console.ResetColor();
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.WriteLine("    ↑↓ naviguer | ←→ modifier | Entree confirmer");
        Console.ResetColor();
        Console.WriteLine();

        // Option 1: Snail count
        if (configIndex == 0)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
        }
        Console.WriteLine($"    Nombre d'escargots:  < {snailCount} >");
        Console.ResetColor();

        // Option 2: Fatigue
        if (configIndex == 1)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
        }
        Console.WriteLine($"    Niveau de fatigue:   < {GetFatigueName(fatigueLevel)} >");
        Console.ResetColor();

        Console.WriteLine();

        ConsoleKeyInfo keyInfo = Console.ReadKey(true);

        if (keyInfo.Key == ConsoleKey.UpArrow)
        {
            configIndex = 0;
        }
        else if (keyInfo.Key == ConsoleKey.DownArrow)
        {
            configIndex = 1;
        }
        else if (keyInfo.Key == ConsoleKey.LeftArrow)
        {
            if (configIndex == 0 && snailCount > 2)
            {
                snailCount--;
            }
            else if (configIndex == 1 && fatigueLevel > 1)
            {
                fatigueLevel--;
            }
        }
        else if (keyInfo.Key == ConsoleKey.RightArrow)
        {
            if (configIndex == 0 && snailCount < 8)
            {
                snailCount++;
            }
            else if (configIndex == 1 && fatigueLevel < 3)
            {
                fatigueLevel++;
            }
        }
        else if (keyInfo.Key == ConsoleKey.Enter)
        {
            configuring = false;
        }
    }

    // Reset bet if snail count changed
    if (betOnSnail >= snailCount)
    {
        betOnSnail = -1;
        currentBet = 0;
    }
}

void Action_Bet()
{
    bool betting = true;
    int betIndex = 0;
    int tempBet = currentBet;
    int tempSnail = betOnSnail;

    while (betting)
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine();
        Console.WriteLine("    ════════════════════════════════");
        Console.WriteLine("              PARIER");
        Console.WriteLine("    ════════════════════════════════");
        Console.ResetColor();
        Console.WriteLine();
        Console.WriteLine($"    Argent disponible: {playerMoney}$");
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.WriteLine("    ↑↓ naviguer | ←→ modifier | Entree confirmer");
        Console.ResetColor();
        Console.WriteLine();

        // Option 1: Bet amount
        if (betIndex == 0)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
        }
        Console.WriteLine($"    Montant du pari:    < {tempBet}$ >");
        Console.ResetColor();

        // Option 2: Snail selection
        if (betIndex == 1)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
        }
        string snailDisplay = tempSnail >= 0 ? $"Escargot #{tempSnail + 1}" : "Aucun";
        Console.WriteLine($"    Parier sur:         < {snailDisplay} >");
        Console.ResetColor();

        Console.WriteLine();

        ConsoleKeyInfo keyInfo = Console.ReadKey(true);

        if (keyInfo.Key == ConsoleKey.UpArrow)
        {
            betIndex = 0;
        }
        else if (keyInfo.Key == ConsoleKey.DownArrow)
        {
            betIndex = 1;
        }
        else if (keyInfo.Key == ConsoleKey.LeftArrow)
        {
            if (betIndex == 0 && tempBet > 0)
            {
                tempBet -= 10;
                if (tempBet < 0) tempBet = 0;
            }
            else if (betIndex == 1 && tempSnail > 0)
            {
                tempSnail--;
            }
        }
        else if (keyInfo.Key == ConsoleKey.RightArrow)
        {
            if (betIndex == 0 && tempBet < playerMoney)
            {
                tempBet += 10;
                if (tempBet > playerMoney) tempBet = playerMoney;
            }
            else if (betIndex == 1 && tempSnail < snailCount - 1)
            {
                tempSnail++;
            }
        }
        else if (keyInfo.Key == ConsoleKey.Enter)
        {
            currentBet = tempBet;
            betOnSnail = tempSnail;
            betting = false;
        }
        else if (keyInfo.Key == ConsoleKey.Escape)
        {
            betting = false;
        }
    }
}

void Action_Statistics()
{
    Console.Clear();
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.WriteLine();
    Console.WriteLine("    ════════════════════════════════");
    Console.WriteLine("           STATISTIQUES");
    Console.WriteLine("    ════════════════════════════════");
    Console.ResetColor();
    Console.WriteLine();
    Console.WriteLine($"    Courses jouees:    {totalRaces}");
    Console.WriteLine($"    Victoires:         {wins}");
    Console.WriteLine($"    Defaites:          {losses}");
    Console.WriteLine();
    Console.WriteLine($"    Argent actuel:     {playerMoney}$");
    Console.WriteLine($"    Pari en cours:     {currentBet}$");
    Console.WriteLine();

    if (totalRaces > 0)
    {
        int winRate = (wins * 100) / totalRaces;
        Console.WriteLine($"    Taux de victoire:  {winRate}%");
    }

    Console.WriteLine();
    Console.WriteLine("    Appuyez sur une touche...");
    Console.ReadKey(true);
}

// =====================================================
// HELPER FUNCTIONS
// =====================================================

string GetFatigueName(int level)
{
    if (level == 1) return "Faible";
    if (level == 2) return "Moyen";
    if (level == 3) return "Eleve";
    return "Inconnu";
}
